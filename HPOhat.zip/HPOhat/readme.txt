Environment
linux

Usage
./hpohat input output database/gene.data 
